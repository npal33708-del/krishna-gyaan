KRISHNA GYAAN — Parampara to Pixels
======================================

A ready-to-upload static website for the "Website / Web App" category.

Files:
- index.html : complete responsive website (HTML/CSS/JS in one file)

How to publish on GitHub Pages:
1. Create/open your GitHub repository.
2. Upload index.html to the repository root.
3. Go to Settings -> Pages.
4. Select Deploy from branch -> main -> / (root).
5. Save and open the generated GitHub Pages URL.

Before submitting:
- Replace/add your college name and your own name/team details if required.
- Add verified source references for educational claims.
- Test the site on phone and laptop.
- Make sure any QR/registration link required by your teacher is added.
